--
-- PostgreSQL database dump
--

\restrict jsv1hY5Lbi0TGNTjBfokd9uu8bHx2cD8eA8AYgSVeKezG63COO8FKh6mu1pxyId

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."RepairStatusHistory" DROP CONSTRAINT IF EXISTS "RepairStatusHistory_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."RepairStatusHistory" DROP CONSTRAINT IF EXISTS "RepairStatusHistory_repairJobId_fkey";
ALTER TABLE IF EXISTS ONLY public."RepairPartUsage" DROP CONSTRAINT IF EXISTS "RepairPartUsage_repairJobId_fkey";
ALTER TABLE IF EXISTS ONLY public."RepairPartUsage" DROP CONSTRAINT IF EXISTS "RepairPartUsage_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."RepairJob" DROP CONSTRAINT IF EXISTS "RepairJob_technicianId_fkey";
ALTER TABLE IF EXISTS ONLY public."RepairJob" DROP CONSTRAINT IF EXISTS "RepairJob_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrder" DROP CONSTRAINT IF EXISTS "PurchaseOrder_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrderItem" DROP CONSTRAINT IF EXISTS "PurchaseOrderItem_purchaseOrderId_fkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrderItem" DROP CONSTRAINT IF EXISTS "PurchaseOrderItem_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProductSerial" DROP CONSTRAINT IF EXISTS "ProductSerial_stockMovementId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProductSerial" DROP CONSTRAINT IF EXISTS "ProductSerial_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public."JournalLine" DROP CONSTRAINT IF EXISTS "JournalLine_journalEntryId_fkey";
ALTER TABLE IF EXISTS ONLY public."JournalLine" DROP CONSTRAINT IF EXISTS "JournalLine_debitAccountId_fkey";
ALTER TABLE IF EXISTS ONLY public."JournalLine" DROP CONSTRAINT IF EXISTS "JournalLine_creditAccountId_fkey";
ALTER TABLE IF EXISTS ONLY public."JournalEntry" DROP CONSTRAINT IF EXISTS "JournalEntry_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public."InvoiceItem" DROP CONSTRAINT IF EXISTS "InvoiceItem_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."InvoiceItem" DROP CONSTRAINT IF EXISTS "InvoiceItem_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_userId_fkey";
DROP INDEX IF EXISTS public."User_username_key";
DROP INDEX IF EXISTS public."User_email_key";
DROP INDEX IF EXISTS public."Supplier_phone_key";
DROP INDEX IF EXISTS public."StockMovement_referenceId_idx";
DROP INDEX IF EXISTS public."StockMovement_productId_idx";
DROP INDEX IF EXISTS public."RepairStatusHistory_repairJobId_idx";
DROP INDEX IF EXISTS public."RepairPartUsage_repairJobId_idx";
DROP INDEX IF EXISTS public."RepairJob_status_idx";
DROP INDEX IF EXISTS public."RepairJob_jobNumber_key";
DROP INDEX IF EXISTS public."RepairJob_jobNumber_idx";
DROP INDEX IF EXISTS public."PurchaseOrder_orderNumber_key";
DROP INDEX IF EXISTS public."Product_sku_key";
DROP INDEX IF EXISTS public."Product_sku_idx";
DROP INDEX IF EXISTS public."Product_category_idx";
DROP INDEX IF EXISTS public."Product_barcode_key";
DROP INDEX IF EXISTS public."Product_barcode_idx";
DROP INDEX IF EXISTS public."ProductSerial_serialNo_idx";
DROP INDEX IF EXISTS public."ProductSerial_productId_serialNo_key";
DROP INDEX IF EXISTS public."ProductSerial_macAddress_idx";
DROP INDEX IF EXISTS public."Payment_method_idx";
DROP INDEX IF EXISTS public."Payment_invoiceId_idx";
DROP INDEX IF EXISTS public."JournalEntry_entryNumber_key";
DROP INDEX IF EXISTS public."Invoice_invoiceNo_key";
DROP INDEX IF EXISTS public."Invoice_invoiceNo_idx";
DROP INDEX IF EXISTS public."Invoice_createdAt_idx";
DROP INDEX IF EXISTS public."InvoiceItem_productId_idx";
DROP INDEX IF EXISTS public."InvoiceItem_invoiceId_idx";
DROP INDEX IF EXISTS public."Customer_phone_key";
DROP INDEX IF EXISTS public."Customer_phone_idx";
DROP INDEX IF EXISTS public."Account_accountCode_key";
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."Supplier" DROP CONSTRAINT IF EXISTS "Supplier_pkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_pkey";
ALTER TABLE IF EXISTS ONLY public."RepairStatusHistory" DROP CONSTRAINT IF EXISTS "RepairStatusHistory_pkey";
ALTER TABLE IF EXISTS ONLY public."RepairPartUsage" DROP CONSTRAINT IF EXISTS "RepairPartUsage_pkey";
ALTER TABLE IF EXISTS ONLY public."RepairJob" DROP CONSTRAINT IF EXISTS "RepairJob_pkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrder" DROP CONSTRAINT IF EXISTS "PurchaseOrder_pkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrderItem" DROP CONSTRAINT IF EXISTS "PurchaseOrderItem_pkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_pkey";
ALTER TABLE IF EXISTS ONLY public."ProductSerial" DROP CONSTRAINT IF EXISTS "ProductSerial_pkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_pkey";
ALTER TABLE IF EXISTS ONLY public."JournalLine" DROP CONSTRAINT IF EXISTS "JournalLine_pkey";
ALTER TABLE IF EXISTS ONLY public."JournalEntry" DROP CONSTRAINT IF EXISTS "JournalEntry_pkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_pkey";
ALTER TABLE IF EXISTS ONLY public."InvoiceItem" DROP CONSTRAINT IF EXISTS "InvoiceItem_pkey";
ALTER TABLE IF EXISTS ONLY public."Customer" DROP CONSTRAINT IF EXISTS "Customer_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_pkey";
ALTER TABLE IF EXISTS ONLY public."Account" DROP CONSTRAINT IF EXISTS "Account_pkey";
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."Supplier";
DROP TABLE IF EXISTS public."StockMovement";
DROP TABLE IF EXISTS public."RepairStatusHistory";
DROP TABLE IF EXISTS public."RepairPartUsage";
DROP TABLE IF EXISTS public."RepairJob";
DROP TABLE IF EXISTS public."PurchaseOrderItem";
DROP TABLE IF EXISTS public."PurchaseOrder";
DROP TABLE IF EXISTS public."ProductSerial";
DROP TABLE IF EXISTS public."Product";
DROP TABLE IF EXISTS public."Payment";
DROP TABLE IF EXISTS public."JournalLine";
DROP TABLE IF EXISTS public."JournalEntry";
DROP TABLE IF EXISTS public."InvoiceItem";
DROP TABLE IF EXISTS public."Invoice";
DROP TABLE IF EXISTS public."Customer";
DROP TABLE IF EXISTS public."AuditLog";
DROP TABLE IF EXISTS public."Account";
DROP TYPE IF EXISTS public."Role";
DROP TYPE IF EXISTS public."RepairStatus";
DROP TYPE IF EXISTS public."PaymentMethod";
DROP TYPE IF EXISTS public."MovementType";
DROP TYPE IF EXISTS public."AccountType";
--
-- Name: AccountType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AccountType" AS ENUM (
    'ASSET',
    'LIABILITY',
    'EQUITY',
    'REVENUE',
    'EXPENSE'
);


--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MovementType" AS ENUM (
    'PURCHASE_RECEIPT',
    'SALE_DEDUCTION',
    'REPAIR_CONSUMPTION',
    'STOCK_ADJUSTMENT',
    'RETURN_TO_SUPPLIER',
    'CUSTOMER_RETURN'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CASH',
    'BANK_TRANSFER',
    'DIGITAL_WALLET',
    'STORE_CREDIT'
);


--
-- Name: RepairStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RepairStatus" AS ENUM (
    'RECEIVED',
    'UNDER_DIAGNOSIS',
    'WAITING_FOR_CUSTOMER_APPROVAL',
    'WAITING_FOR_PARTS',
    'IN_REPAIR',
    'TESTING_QC',
    'READY_FOR_COLLECTION',
    'DELIVERED',
    'ON_HOLD',
    'CANCELLED',
    'UNREPAIRABLE',
    'WARRANTY_RETURN'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'OWNER',
    'ADMIN',
    'ACCOUNTANT',
    'CASHIER',
    'INVENTORY_MANAGER',
    'TECHNICIAN'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "accountCode" text NOT NULL,
    name text NOT NULL,
    type public."AccountType" NOT NULL,
    balance numeric(14,2) DEFAULT 0.0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    metadata jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    "fullName" text NOT NULL,
    phone text NOT NULL,
    email text,
    address text,
    "creditLimit" numeric(12,2) DEFAULT 0.0 NOT NULL,
    "balanceDue" numeric(12,2) DEFAULT 0.0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "invoiceNo" text NOT NULL,
    "customerId" text NOT NULL,
    "subTotal" numeric(12,2) NOT NULL,
    "taxAmount" numeric(12,2) NOT NULL,
    discount numeric(12,2) DEFAULT 0.0 NOT NULL,
    "grandTotal" numeric(12,2) NOT NULL,
    "paidAmount" numeric(12,2) DEFAULT 0.0 NOT NULL,
    "isPaid" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "changeAmount" numeric(12,2) DEFAULT 0.0 NOT NULL,
    notes text,
    "userId" text
);


--
-- Name: InvoiceItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InvoiceItem" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "productId" text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(12,2) NOT NULL,
    "totalPrice" numeric(12,2) NOT NULL,
    "costPrice" numeric(12,2) DEFAULT 0.0 NOT NULL
);


--
-- Name: JournalEntry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JournalEntry" (
    id text NOT NULL,
    "entryNumber" text NOT NULL,
    reference text,
    memo text NOT NULL,
    "userId" text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JournalLine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JournalLine" (
    id text NOT NULL,
    "journalEntryId" text NOT NULL,
    "debitAccountId" text,
    "creditAccountId" text,
    amount numeric(12,2) NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    amount numeric(12,2) NOT NULL,
    method public."PaymentMethod" NOT NULL,
    "referenceNo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    sku text NOT NULL,
    barcode text,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    brand text,
    model text,
    "costPrice" numeric(12,2) NOT NULL,
    "retailPrice" numeric(12,2) NOT NULL,
    "stockQuantity" integer DEFAULT 0 NOT NULL,
    "minStockAlert" integer DEFAULT 5 NOT NULL,
    "isSparePart" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ProductSerial; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductSerial" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "serialNo" text NOT NULL,
    imei text,
    "macAddress" text,
    "isSold" boolean DEFAULT false NOT NULL,
    "stockMovementId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PurchaseOrder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PurchaseOrder" (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    "supplierId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "totalCost" numeric(12,2) DEFAULT 0.0 NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PurchaseOrderItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PurchaseOrderItem" (
    id text NOT NULL,
    "purchaseOrderId" text NOT NULL,
    "productId" text NOT NULL,
    "orderedQuantity" integer NOT NULL,
    "receivedQuantity" integer DEFAULT 0 NOT NULL,
    "unitCost" numeric(12,2) NOT NULL,
    "totalCost" numeric(12,2) NOT NULL
);


--
-- Name: RepairJob; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RepairJob" (
    id text NOT NULL,
    "jobNumber" text NOT NULL,
    "customerId" text NOT NULL,
    "technicianId" text,
    "deviceType" text NOT NULL,
    brand text NOT NULL,
    model text NOT NULL,
    "serialNumber" text,
    "reportedFault" text NOT NULL,
    "physicalCondition" text,
    accessories text,
    "diagnosticReport" text,
    status public."RepairStatus" DEFAULT 'RECEIVED'::public."RepairStatus" NOT NULL,
    "estimatedCost" numeric(12,2),
    "finalLaborCost" numeric(12,2) DEFAULT 0.0 NOT NULL,
    "finalPartsCost" numeric(12,2) DEFAULT 0.0 NOT NULL,
    "totalCost" numeric(12,2) DEFAULT 0.0 NOT NULL,
    "customerApproved" boolean DEFAULT false NOT NULL,
    "internalNotes" text,
    "receivedDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedDate" timestamp(3) without time zone,
    "deliveredDate" timestamp(3) without time zone,
    "approvedAt" timestamp(3) without time zone,
    "deliveredTo" text,
    "qcNotes" text,
    "qcPassed" boolean DEFAULT false NOT NULL,
    "securityPin" text,
    "warrantyDays" integer DEFAULT 30 NOT NULL
);


--
-- Name: RepairPartUsage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RepairPartUsage" (
    id text NOT NULL,
    "repairJobId" text NOT NULL,
    "productId" text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "unitPrice" numeric(12,2) NOT NULL,
    "totalPrice" numeric(12,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RepairStatusHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RepairStatusHistory" (
    id text NOT NULL,
    "repairJobId" text NOT NULL,
    "userId" text NOT NULL,
    "fromStatus" public."RepairStatus" NOT NULL,
    "toStatus" public."RepairStatus" NOT NULL,
    note text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "userId" text NOT NULL,
    "movementType" public."MovementType" NOT NULL,
    "quantityDelta" integer NOT NULL,
    "unitCost" numeric(12,2) NOT NULL,
    "referenceId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Supplier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Supplier" (
    id text NOT NULL,
    "companyName" text NOT NULL,
    "contactPerson" text,
    email text,
    phone text NOT NULL,
    address text,
    "taxNumber" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "fullName" text NOT NULL,
    role public."Role" DEFAULT 'CASHIER'::public."Role" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, "accountCode", name, type, balance, "createdAt") FROM stdin;
ce36947a-14b0-49f0-bfd7-3a9b16a7f699	2010	Accounts Payable	LIABILITY	0.00	2026-10-28 15:14:25.973
e38205f3-2606-48ed-a7ad-b5b03bc10c23	3010	Owner Equity	EQUITY	0.00	2026-10-28 15:14:25.99
7ebca875-bec3-4998-aeb7-86f1d14b8359	4020	Repair & Service Labor Revenue	REVENUE	0.00	2026-10-28 15:14:26.007
f2c930b6-6df2-4b68-be25-62ed0c95d235	1020	Operating Bank Account	ASSET	6000.00	2026-10-28 15:14:25.948
73f9f7ef-802d-4a42-81d9-978b2a460889	1200	Accounts Receivable	ASSET	27610.00	2026-10-28 15:14:25.957
7c4e477d-daac-4b79-b11a-2c6b240de6b6	5030	Shop Utilities & Fiber Internet	EXPENSE	4500.00	2026-10-28 15:47:29.381
f8690345-c6df-4de6-8e52-13b14bafe5d5	1010	Cash on Hand	ASSET	10254.00	2026-10-28 15:14:25.941
26617e23-be90-4bd6-a1d6-5fc0fc9e99f9	4010	Retail Hardware Sales	REVENUE	42800.00	2026-10-28 15:14:25.998
5b8ce6a3-a3ec-43b8-b239-b511416af035	2020	VAT/Tax Payable	LIABILITY	5564.00	2026-10-28 15:14:25.981
9516fe8d-cf68-4bed-be13-0222e4c2b0cb	5010	Cost of Goods Sold (COGS)	EXPENSE	-50800.00	2026-10-28 15:14:26.015
f1975e5e-ee2b-42b2-9bef-e546fb11b53e	5020	Workshop Consumables & Parts Cost	EXPENSE	8400.00	2026-10-28 15:14:26.023
95006805-53e1-4042-b027-a4bdabf1ddbb	1300	Merchandise Inventory	ASSET	42400.00	2026-10-28 15:14:25.965
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "userId", action, entity, "entityId", metadata, "ipAddress", "createdAt") FROM stdin;
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customer" (id, "fullName", phone, email, address, "creditLimit", "balanceDue", "createdAt", "updatedAt") FROM stdin;
0ac4c279-a996-4948-8d2e-0df890574dca	Pradeep Khadka Enterprise	+977-98016245	pradeep@khadka.com.np	Putalisadak, Kathmandu	15000.00	0.00	2026-10-28 15:38:38.786	2026-10-28 15:38:38.786
185eddf7-8c65-48da-9fef-66f1aecb480e	Pradeep Khadka Enterprise	+977-9801786	pradeep@khadka.com.np	Putalisadak, Kathmandu	15000.00	13805.00	2026-10-28 15:42:06.694	2026-10-28 15:42:07.23
823c2f6b-db63-4769-a6fe-5fd0beb7c6df	Pradeep Khadka Enterprise	+977-98017358	pradeep@khadka.com.np	Putalisadak, Kathmandu	15000.00	13805.00	2026-10-28 15:42:15.055	2026-10-28 15:42:15.568
1691fbcd-9bb3-4e5d-a049-c772d6b90e86	Suman Sharma	+977-9841223344	suman@sharma.np	Baneshwor, Kathmandu	0.00	0.00	2026-10-28 15:31:39.242	2026-10-28 18:50:33.205
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Invoice" (id, "invoiceNo", "customerId", "subTotal", "taxAmount", discount, "grandTotal", "paidAmount", "isPaid", "createdAt", "changeAmount", notes, "userId") FROM stdin;
a1d921c8-feb8-4804-9531-b27cb29a7cff	INV-20261028-0001	185eddf7-8c65-48da-9fef-66f1aecb480e	9500.00	1170.00	500.00	10170.00	7000.00	f	2026-10-28 15:42:07.03	0.00	Counter POS retail sale with warranty	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c
3363c17e-4aeb-4db4-855e-41fe49c7368f	INV-20261028-0002	185eddf7-8c65-48da-9fef-66f1aecb480e	9500.00	1235.00	0.00	10735.00	100.00	f	2026-10-28 15:42:07.232	0.00	\N	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c
4bdb7572-27b1-4d48-b22c-a3c0a15db164	INV-20261028-0003	823c2f6b-db63-4769-a6fe-5fd0beb7c6df	9500.00	1170.00	500.00	10170.00	7000.00	f	2026-10-28 15:42:15.417	0.00	Counter POS retail sale with warranty	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c
eafe403e-78d0-48ed-9ab4-6ae8fcf14fd3	INV-20261028-0004	823c2f6b-db63-4769-a6fe-5fd0beb7c6df	9500.00	1235.00	0.00	10735.00	100.00	f	2026-10-28 15:42:15.569	0.00	\N	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c
50e4eaeb-3288-44a6-8dab-5e0f21bf2472	INV-20261028-0005	1691fbcd-9bb3-4e5d-a049-c772d6b90e86	5800.00	754.00	0.00	6554.00	6554.00	t	2026-10-28 18:41:09.867	0.00	\N	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c
\.


--
-- Data for Name: InvoiceItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InvoiceItem" (id, "invoiceId", "productId", quantity, "unitPrice", "totalPrice", "costPrice") FROM stdin;
724cde11-3e7b-491c-8183-ddd530722b16	a1d921c8-feb8-4804-9531-b27cb29a7cff	b08173c3-024a-40f4-bc15-7dc70d449d4e	1	9500.00	9500.00	6500.00
c63945ce-2883-47d1-93d3-7028571b32a8	3363c17e-4aeb-4db4-855e-41fe49c7368f	b08173c3-024a-40f4-bc15-7dc70d449d4e	1	9500.00	9500.00	6500.00
510af039-df73-494b-b9ee-295035944710	4bdb7572-27b1-4d48-b22c-a3c0a15db164	c1d1f985-b515-4960-b213-42185e0939af	1	9500.00	9500.00	6500.00
16b45812-777f-450d-b00b-e23f3f0f9f79	eafe403e-78d0-48ed-9ab4-6ae8fcf14fd3	c1d1f985-b515-4960-b213-42185e0939af	1	9500.00	9500.00	6500.00
d25fd823-9fd8-4f4a-b4a7-a2943a30691a	50e4eaeb-3288-44a6-8dab-5e0f21bf2472	84c03562-ec15-47c0-b86a-01962f2f1a55	1	5800.00	5800.00	4200.00
\.


--
-- Data for Name: JournalEntry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JournalEntry" (id, "entryNumber", reference, memo, "userId", date, "createdAt") FROM stdin;
40d55a33-cef0-42f8-a120-aebfeecd54b0	JE-1793201115910-480	628acb8c-ba33-44c4-94a1-ec6676ac5a71	Inventory Adjustment Gain: SPARE-SSD-512-2503 (Initial workshop spare parts stock intake)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:25:15.918	2026-10-28 15:25:15.918
665931e6-1704-471b-90dd-975031a2df1b	JE-1793201499205-600	e6e9d3e9-ebd4-4b24-a07f-4488ec29fcf0	Inventory Adjustment Gain: SPARE-SSD-512-3390 (Initial workshop spare parts stock intake)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:31:39.21	2026-10-28 15:31:39.21
450168c5-826b-4941-9b69-4e6582a50d0b	JE-1793201499441-625	JOB-20261028-0001	Spare parts consumed: Samsung 980 512GB NVMe M.2 SSD (Qty: 1) for Job JOB-20261028-0001	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:31:39.447	2026-10-28 15:31:39.447
00d1954d-9e2f-4747-b6b7-8c95d3bd7c74	JE-1793201918677-674	81d66eaa-fa50-4b88-848b-a1f519694b73	Inventory Adjustment Gain: RUIJIE-AX3000-21665 (POS inventory batch intake)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:38:38.684	2026-10-28 15:38:38.684
43401db6-a65f-4f4d-8768-15b365c6c5f8	JE-1793202126586-390	a9a719fe-44e6-4c57-805f-eedbb42530a3	Inventory Adjustment Gain: RUIJIE-AX3000-2372 (POS inventory batch intake)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:42:06.593	2026-10-28 15:42:06.593
16121288-19a8-4608-ab06-edd6c12053ed	JE-1793202127040-105	INV-20261028-0001	POS Sales Posting: INV-20261028-0001 (Pradeep Khadka Enterprise)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:42:07.05	2026-10-28 15:42:07.05
39e7355f-b8ed-4a2d-a1c1-bd707fbf9b0c	JE-1793202127238-185	INV-20261028-0002	POS Sales Posting: INV-20261028-0002 (Pradeep Khadka Enterprise)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:42:07.247	2026-10-28 15:42:07.247
616c01d8-5728-4eb4-96fa-ea0fb71bbf48	JE-1793202134944-816	97bbf999-d5f6-4c08-99e4-59aa2d1d2415	Inventory Adjustment Gain: RUIJIE-AX3000-21946 (POS inventory batch intake)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:42:14.948	2026-10-28 15:42:14.948
5631225c-b595-44bf-b56e-d574c1fe543c	JE-1793202135422-319	INV-20261028-0003	POS Sales Posting: INV-20261028-0003 (Pradeep Khadka Enterprise)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:42:15.432	2026-10-28 15:42:15.432
f42f0c21-70e5-4a57-86b9-acf9658222e9	JE-1793202135578-892	INV-20261028-0004	POS Sales Posting: INV-20261028-0004 (Pradeep Khadka Enterprise)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:42:15.592	2026-10-28 15:42:15.592
c048dcd4-d51b-4afc-b8b6-6940d1b63f21	JV-20261028-0011	VOUCH-INT-2026	Dedicated 200Mbps Fiber payment from Petty Cash	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 15:47:29.441	2026-10-28 15:47:29.449
cb18dcca-c312-44ac-96c9-0942ca258148	JE-1793212869881-856	INV-20261028-0005	POS Sales Posting: INV-20261028-0005 (Suman Sharma)	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 18:41:09.89	2026-10-28 18:41:09.89
d3ad01e8-8c86-4046-8a88-274a2e26f68e	JE-1793213433332-830	JOB-20261028-0005	Spare parts consumed: Samsung 980 512GB NVMe M.2 SSD (Qty: 1) for Job JOB-20261028-0005	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	2026-10-28 18:50:33.337	2026-10-28 18:50:33.337
\.


--
-- Data for Name: JournalLine; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JournalLine" (id, "journalEntryId", "debitAccountId", "creditAccountId", amount) FROM stdin;
75e5a430-b9b0-4dd2-b974-5faa228e0193	40d55a33-cef0-42f8-a120-aebfeecd54b0	95006805-53e1-4042-b027-a4bdabf1ddbb	\N	21000.00
1c3395b5-3eb5-4d39-b743-7843700b331c	40d55a33-cef0-42f8-a120-aebfeecd54b0	\N	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	21000.00
8a620053-9dc9-4d5a-8b06-d0f723f04279	665931e6-1704-471b-90dd-975031a2df1b	95006805-53e1-4042-b027-a4bdabf1ddbb	\N	21000.00
cb171b12-bb89-4cb5-b2af-07046aadf20f	665931e6-1704-471b-90dd-975031a2df1b	\N	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	21000.00
044223ff-4322-4435-a5ae-370345ad4908	450168c5-826b-4941-9b69-4e6582a50d0b	f1975e5e-ee2b-42b2-9bef-e546fb11b53e	\N	4200.00
3fa2e94a-c0de-49b9-ac23-f2d5299bd244	450168c5-826b-4941-9b69-4e6582a50d0b	\N	95006805-53e1-4042-b027-a4bdabf1ddbb	4200.00
be8dcec7-1360-48b0-8fc3-653250ac95a6	00d1954d-9e2f-4747-b6b7-8c95d3bd7c74	95006805-53e1-4042-b027-a4bdabf1ddbb	\N	13000.00
3b66295b-ac42-4eaf-b679-a36ffa8df51c	00d1954d-9e2f-4747-b6b7-8c95d3bd7c74	\N	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	13000.00
98b7c0e0-d059-43fe-b513-3c7582bb2ddd	43401db6-a65f-4f4d-8768-15b365c6c5f8	95006805-53e1-4042-b027-a4bdabf1ddbb	\N	13000.00
a330776e-d976-4036-9b3a-d9484fe342d4	43401db6-a65f-4f4d-8768-15b365c6c5f8	\N	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	13000.00
c61c0c23-5002-4b42-b577-7b906355cfe1	16121288-19a8-4608-ab06-edd6c12053ed	f8690345-c6df-4de6-8e52-13b14bafe5d5	\N	4000.00
6f79de83-cd01-4ab1-bcfe-12ea4f21e0f3	16121288-19a8-4608-ab06-edd6c12053ed	f2c930b6-6df2-4b68-be25-62ed0c95d235	\N	3000.00
46fa53e7-0fc1-437a-a18c-96171c48b1e9	16121288-19a8-4608-ab06-edd6c12053ed	73f9f7ef-802d-4a42-81d9-978b2a460889	\N	3170.00
eca33c2d-096a-404a-b186-552a7ef1a458	16121288-19a8-4608-ab06-edd6c12053ed	\N	26617e23-be90-4bd6-a1d6-5fc0fc9e99f9	9000.00
43ed395b-2c10-4870-996d-33c9b860a765	16121288-19a8-4608-ab06-edd6c12053ed	\N	5b8ce6a3-a3ec-43b8-b239-b511416af035	1170.00
23244bbd-4641-447b-bd5f-f616a8c08cc0	16121288-19a8-4608-ab06-edd6c12053ed	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	\N	6500.00
0b940a79-d51e-4d58-9f73-af45067a12df	16121288-19a8-4608-ab06-edd6c12053ed	\N	95006805-53e1-4042-b027-a4bdabf1ddbb	6500.00
43b91d87-4526-42d7-88e1-c92b9051ee17	39e7355f-b8ed-4a2d-a1c1-bd707fbf9b0c	f8690345-c6df-4de6-8e52-13b14bafe5d5	\N	100.00
6c3d2964-8632-4ab3-b8e6-9650353495b3	39e7355f-b8ed-4a2d-a1c1-bd707fbf9b0c	73f9f7ef-802d-4a42-81d9-978b2a460889	\N	10635.00
df1479b5-7759-46f2-ac72-d147d2e437e6	39e7355f-b8ed-4a2d-a1c1-bd707fbf9b0c	\N	26617e23-be90-4bd6-a1d6-5fc0fc9e99f9	9500.00
05488452-b330-4c04-9f3d-43c1f016aa34	39e7355f-b8ed-4a2d-a1c1-bd707fbf9b0c	\N	5b8ce6a3-a3ec-43b8-b239-b511416af035	1235.00
96a82ab1-f8d6-4d4b-af65-669e42f3e41c	39e7355f-b8ed-4a2d-a1c1-bd707fbf9b0c	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	\N	6500.00
2fe18b36-3667-4cf8-9890-aaa063283184	39e7355f-b8ed-4a2d-a1c1-bd707fbf9b0c	\N	95006805-53e1-4042-b027-a4bdabf1ddbb	6500.00
49f889bb-71c6-43a7-9701-de1a2abfdfe7	616c01d8-5728-4eb4-96fa-ea0fb71bbf48	95006805-53e1-4042-b027-a4bdabf1ddbb	\N	13000.00
c45ef809-aa96-4179-96df-30daf920b870	616c01d8-5728-4eb4-96fa-ea0fb71bbf48	\N	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	13000.00
c56a80b1-ddea-4720-8869-03bd1d67b194	5631225c-b595-44bf-b56e-d574c1fe543c	f8690345-c6df-4de6-8e52-13b14bafe5d5	\N	4000.00
ebc46bd0-d5ce-4209-9f9f-91cabc3461ff	5631225c-b595-44bf-b56e-d574c1fe543c	f2c930b6-6df2-4b68-be25-62ed0c95d235	\N	3000.00
16d74186-a50a-4660-b82f-68ddbada2bf2	5631225c-b595-44bf-b56e-d574c1fe543c	73f9f7ef-802d-4a42-81d9-978b2a460889	\N	3170.00
969dd7fa-dba6-4d90-a178-b52079bdca3b	5631225c-b595-44bf-b56e-d574c1fe543c	\N	26617e23-be90-4bd6-a1d6-5fc0fc9e99f9	9000.00
ac2ccb75-579e-48a0-8baa-b0574175b370	5631225c-b595-44bf-b56e-d574c1fe543c	\N	5b8ce6a3-a3ec-43b8-b239-b511416af035	1170.00
9e815021-4e49-4e99-b943-70630836e13c	5631225c-b595-44bf-b56e-d574c1fe543c	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	\N	6500.00
2d051b98-aa6e-49c5-ae23-50217a2d0205	5631225c-b595-44bf-b56e-d574c1fe543c	\N	95006805-53e1-4042-b027-a4bdabf1ddbb	6500.00
b3b4f2d0-9061-40c2-95cc-1b9c6a705dc2	f42f0c21-70e5-4a57-86b9-acf9658222e9	f8690345-c6df-4de6-8e52-13b14bafe5d5	\N	100.00
dd64dc7b-c637-4574-b911-0d928ab62977	f42f0c21-70e5-4a57-86b9-acf9658222e9	73f9f7ef-802d-4a42-81d9-978b2a460889	\N	10635.00
b08e8832-1cd9-475b-9cff-91d00d82b453	f42f0c21-70e5-4a57-86b9-acf9658222e9	\N	26617e23-be90-4bd6-a1d6-5fc0fc9e99f9	9500.00
f6e50310-e42b-40a3-9a56-d9e073e399a6	f42f0c21-70e5-4a57-86b9-acf9658222e9	\N	5b8ce6a3-a3ec-43b8-b239-b511416af035	1235.00
b4b268b0-129d-4c74-bdd5-55117267f9be	f42f0c21-70e5-4a57-86b9-acf9658222e9	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	\N	6500.00
c6c0a53b-8a96-4ee1-83fb-8e73451ecb2e	f42f0c21-70e5-4a57-86b9-acf9658222e9	\N	95006805-53e1-4042-b027-a4bdabf1ddbb	6500.00
98bfe520-9f93-4cbd-8b28-8c9fe5374361	c048dcd4-d51b-4afc-b8b6-6940d1b63f21	7c4e477d-daac-4b79-b11a-2c6b240de6b6	\N	4500.00
87a0df6c-f17b-4ef5-91a9-af39ee2729c2	c048dcd4-d51b-4afc-b8b6-6940d1b63f21	\N	f8690345-c6df-4de6-8e52-13b14bafe5d5	4500.00
5de1b3cc-4ae9-40de-a81f-eb2c1275bacc	cb18dcca-c312-44ac-96c9-0942ca258148	f8690345-c6df-4de6-8e52-13b14bafe5d5	\N	6554.00
747a0cbd-cfb5-4c00-8540-b2134b853a07	cb18dcca-c312-44ac-96c9-0942ca258148	\N	26617e23-be90-4bd6-a1d6-5fc0fc9e99f9	5800.00
f83a1c4d-4fbe-4d61-929b-22b1e1bfe809	cb18dcca-c312-44ac-96c9-0942ca258148	\N	5b8ce6a3-a3ec-43b8-b239-b511416af035	754.00
acabafb5-2e1e-4bc0-a9ba-e57925bece23	cb18dcca-c312-44ac-96c9-0942ca258148	9516fe8d-cf68-4bed-be13-0222e4c2b0cb	\N	4200.00
2f950a3d-620a-41d3-8693-4094bf8e5201	cb18dcca-c312-44ac-96c9-0942ca258148	\N	95006805-53e1-4042-b027-a4bdabf1ddbb	4200.00
626fdae9-7dbc-4634-8b7a-6ad67bc37157	d3ad01e8-8c86-4046-8a88-274a2e26f68e	f1975e5e-ee2b-42b2-9bef-e546fb11b53e	\N	4200.00
bb44a038-894f-43ab-af72-a4a3e78725ac	d3ad01e8-8c86-4046-8a88-274a2e26f68e	\N	95006805-53e1-4042-b027-a4bdabf1ddbb	4200.00
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, "invoiceId", amount, method, "referenceNo", "createdAt") FROM stdin;
d8de23e0-a05a-4170-a672-d99b575736bf	a1d921c8-feb8-4804-9531-b27cb29a7cff	4000.00	CASH	\N	2026-10-28 15:42:07.03
15e3a1d6-88fa-40c8-9380-865b2ed8ad38	a1d921c8-feb8-4804-9531-b27cb29a7cff	3000.00	DIGITAL_WALLET	ESEWA-992128	2026-10-28 15:42:07.03
89b3da76-0af4-41fe-95c9-f6b13e90c5fe	3363c17e-4aeb-4db4-855e-41fe49c7368f	100.00	CASH	\N	2026-10-28 15:42:07.232
45f16711-47aa-463b-b487-ccca5c9600d9	4bdb7572-27b1-4d48-b22c-a3c0a15db164	4000.00	CASH	\N	2026-10-28 15:42:15.417
5beed1ad-4627-48d5-b164-3955dbd63cc4	4bdb7572-27b1-4d48-b22c-a3c0a15db164	3000.00	DIGITAL_WALLET	ESEWA-992128	2026-10-28 15:42:15.417
4d79340a-39a2-4895-98e4-a21d039d0786	eafe403e-78d0-48ed-9ab4-6ae8fcf14fd3	100.00	CASH	\N	2026-10-28 15:42:15.569
bf9513ed-57a5-40fc-80fb-d44f68d247f0	50e4eaeb-3288-44a6-8dab-5e0f21bf2472	6554.00	CASH	\N	2026-10-28 18:41:09.867
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Product" (id, sku, barcode, name, description, category, brand, model, "costPrice", "retailPrice", "stockQuantity", "minStockAlert", "isSparePart", "createdAt", "updatedAt") FROM stdin;
5362315a-0df7-4c1f-8699-de15e810b868	RG-NBS3100-24GT4SFP-10118	69412345610118	Ruijie Reyee 24-Port Gigabit L2 Managed Switch	\N	Networking	Ruijie	RG-NBS3100-24GT4SFP-P	18500.00	23500.00	0	2	f	2026-10-28 15:17:41.777	2026-10-28 15:17:41.777
bbc7363d-5a50-445c-8028-526be96cdd25	SPARE-SSD-512-3390	\N	Samsung 980 512GB NVMe M.2 SSD	\N	Spare Parts	\N	\N	4200.00	5800.00	4	5	t	2026-10-28 15:31:39.135	2026-10-28 15:31:39.437
e4ba8a79-76df-48a1-8085-3bb61be5126e	RUIJIE-AX3000-21665	69712341728	Ruijie Reyee RG-EW3200GX PRO Wi-Fi 6 Mesh Router	\N	Networking	Ruijie	RG-EW3200GX-PRO	6500.00	9500.00	2	1	f	2026-10-28 15:38:38.622	2026-10-28 15:38:38.672
b08173c3-024a-40f4-bc15-7dc70d449d4e	RUIJIE-AX3000-2372	697123426989	Ruijie Reyee RG-EW3200GX PRO Wi-Fi 6 Mesh Router	\N	Networking	Ruijie	RG-EW3200GX-PRO	6500.00	9500.00	0	1	f	2026-10-28 15:42:06.518	2026-10-28 15:42:07.236
c1d1f985-b515-4960-b213-42185e0939af	RUIJIE-AX3000-21946	69712343741	Ruijie Reyee RG-EW3200GX PRO Wi-Fi 6 Mesh Router	\N	Networking	Ruijie	RG-EW3200GX-PRO	6500.00	9500.00	0	1	f	2026-10-28 15:42:14.878	2026-10-28 15:42:15.574
84c03562-ec15-47c0-b86a-01962f2f1a55	SPARE-SSD-512-2503	\N	Samsung 980 512GB NVMe M.2 SSD	\N	Spare Parts	\N	\N	4200.00	5800.00	3	5	t	2026-10-28 15:25:15.863	2026-10-28 18:50:33.328
\.


--
-- Data for Name: ProductSerial; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductSerial" (id, "productId", "serialNo", imei, "macAddress", "isSold", "stockMovementId", "createdAt") FROM stdin;
3f1e9a60-af42-48b7-9959-216a22ffd333	e4ba8a79-76df-48a1-8085-3bb61be5126e	RG-AX3K-SN01-27399	\N	00:1A:2B:AA:BB:01	f	81d66eaa-fa50-4b88-848b-a1f519694b73	2026-10-28 15:38:38.676
b85afd60-4588-4d5e-a4d6-e180208f3bcd	e4ba8a79-76df-48a1-8085-3bb61be5126e	RG-AX3K-SN02-12529	\N	00:1A:2B:AA:BB:02	f	81d66eaa-fa50-4b88-848b-a1f519694b73	2026-10-28 15:38:38.676
127ad78e-4343-4c99-938d-0068cc0dcc2a	b08173c3-024a-40f4-bc15-7dc70d449d4e	RG-AX3K-SN01-26970	\N	00:1A:2B:AA:BB:01	t	89d430fe-f5ff-4204-9fa1-dfb70d8230b4	2026-10-28 15:42:06.585
29c35858-8639-4730-8f55-2b75c63ac6d5	b08173c3-024a-40f4-bc15-7dc70d449d4e	RG-AX3K-SN02-17242	\N	00:1A:2B:AA:BB:02	t	7bd878c9-782f-4588-99d3-bae1f1ebc0fd	2026-10-28 15:42:06.585
bc996468-a690-4c19-acdd-a9a8180e6d5a	c1d1f985-b515-4960-b213-42185e0939af	RG-AX3K-SN01-10680	\N	00:1A:2B:AA:BB:01	t	cf316a07-baea-49be-80ce-128c02836fa7	2026-10-28 15:42:14.943
81a936e4-e450-446a-ac57-73742a5f37dd	c1d1f985-b515-4960-b213-42185e0939af	RG-AX3K-SN02-535	\N	00:1A:2B:AA:BB:02	t	52aa2869-fa29-4204-b32e-6f0bafa97fdc	2026-10-28 15:42:14.943
\.


--
-- Data for Name: PurchaseOrder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PurchaseOrder" (id, "orderNumber", "supplierId", status, "totalCost", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PurchaseOrderItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PurchaseOrderItem" (id, "purchaseOrderId", "productId", "orderedQuantity", "receivedQuantity", "unitCost", "totalCost") FROM stdin;
\.


--
-- Data for Name: RepairJob; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RepairJob" (id, "jobNumber", "customerId", "technicianId", "deviceType", brand, model, "serialNumber", "reportedFault", "physicalCondition", accessories, "diagnosticReport", status, "estimatedCost", "finalLaborCost", "finalPartsCost", "totalCost", "customerApproved", "internalNotes", "receivedDate", "completedDate", "deliveredDate", "approvedAt", "deliveredTo", "qcNotes", "qcPassed", "securityPin", "warrantyDays") FROM stdin;
a4cc7c91-919a-4c91-b906-0f64b3fad1d0	JOB-20261028-0001	1691fbcd-9bb3-4e5d-a049-c772d6b90e86	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	Laptop	Dell	Latitude 5420	DELL-LT-9921	System will not boot past BIOS. Storage drive not detected.	Minor scratch on top lid. All screws intact.	Original 65W USB-C Charger	Original M.2 SATA SSD failed with I/O errors. Recommend replacement with 512GB NVMe SSD and OS reinstallation.	DELIVERED	7300.00	1500.00	5800.00	7300.00	t	[Diag]: Customer requested keeping the old drive if recovery is possible.\n[Approval]: Approved via phone call at 2:30 PM.	2026-10-28 15:31:39.247	2026-10-28 15:31:39.508	2026-10-28 15:31:39.526	2026-10-28 15:31:39.406	Suman Sharma (Self)	All hardware diagnostics passed. Battery health: 88%. Thermals under 65C.	t	1995	30
ac48cc9d-4c11-4187-a9c9-d274be09aace	JOB-20261028-0002	0ac4c279-a996-4948-8d2e-0df890574dca	\N	Consultation	Internal	Profile Setup	\N	Initial account profile setup	\N	\N	\N	RECEIVED	\N	0.00	0.00	0.00	f	\N	2026-10-28 15:38:38.792	\N	\N	\N	\N	\N	f	\N	30
91939b80-1b64-4b28-98f1-2531cef8fb84	JOB-20261028-0003	185eddf7-8c65-48da-9fef-66f1aecb480e	\N	Consultation	Internal	Profile Setup	\N	Initial account profile setup	\N	\N	\N	RECEIVED	\N	0.00	0.00	0.00	f	\N	2026-10-28 15:42:06.698	\N	\N	\N	\N	\N	f	\N	30
247a7fb5-f504-4cdd-9639-d6664932ac78	JOB-20261028-0004	823c2f6b-db63-4769-a6fe-5fd0beb7c6df	\N	Consultation	Internal	Profile Setup	\N	Initial account profile setup	\N	\N	\N	RECEIVED	\N	0.00	0.00	0.00	f	\N	2026-10-28 15:42:15.057	\N	\N	\N	\N	\N	f	\N	30
7be48258-b929-46f5-ac2e-c02a60b06b8a	JOB-20261028-0005	1691fbcd-9bb3-4e5d-a049-c772d6b90e86	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	LAPTOP	Dell	XPS 15 9500	SN-DELL-9500-1793213433	NVMe SSD failure; system unable to boot into OS	Chassis scuffs; screen and keyboard intact	Original 130W USB-C Charger	Boot partition corrupted on drive. Confirmed replacement with Samsung 980 512GB NVMe SSD.	IN_REPAIR	7500.00	0.00	5800.00	5800.00	t	[Approval]: Customer verbal authorization recorded for NPR 7,500.00 total repair cost	2026-10-28 18:50:33.21	\N	\N	2026-10-28 18:50:33.297	\N	\N	f	\N	30
\.


--
-- Data for Name: RepairPartUsage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RepairPartUsage" (id, "repairJobId", "productId", quantity, "unitPrice", "totalPrice", "createdAt") FROM stdin;
4beb38c2-2635-44d6-bd8e-9ae6c5cc8200	a4cc7c91-919a-4c91-b906-0f64b3fad1d0	bbc7363d-5a50-445c-8028-526be96cdd25	1	5800.00	5800.00	2026-10-28 15:31:39.436
185b552c-15a5-4c33-a624-8d63544fb42c	7be48258-b929-46f5-ac2e-c02a60b06b8a	84c03562-ec15-47c0-b86a-01962f2f1a55	1	5800.00	5800.00	2026-10-28 18:50:33.327
\.


--
-- Data for Name: RepairStatusHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RepairStatusHistory" (id, "repairJobId", "userId", "fromStatus", "toStatus", note, "createdAt") FROM stdin;
a0ec4aad-8254-44bc-91e2-a5d0b8c02083	a4cc7c91-919a-4c91-b906-0f64b3fad1d0	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	RECEIVED	RECEIVED	Initial hardware intake completed.	2026-10-28 15:31:39.25
1d539738-0daa-49f2-aa24-3fd08f6f27bb	a4cc7c91-919a-4c91-b906-0f64b3fad1d0	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	RECEIVED	UNDER_DIAGNOSIS	Diagnosis recorded: Estimate NPR 7300	2026-10-28 15:31:39.372
36af20ef-0a3e-4368-940b-e4e88cf34204	a4cc7c91-919a-4c91-b906-0f64b3fad1d0	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	UNDER_DIAGNOSIS	IN_REPAIR	Customer approved estimate.	2026-10-28 15:31:39.408
f7aafe67-fd91-4d82-80ba-c5eb3dc7a48b	a4cc7c91-919a-4c91-b906-0f64b3fad1d0	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	IN_REPAIR	TESTING_QC	Hardware assembled. Running 30-minute stress test and OS driver checks.	2026-10-28 15:31:39.476
e3210f35-f3ec-4427-950c-ffcbebc784eb	a4cc7c91-919a-4c91-b906-0f64b3fad1d0	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	TESTING_QC	READY_FOR_COLLECTION	Customer notified via SMS for collection.	2026-10-28 15:31:39.512
5dc4e8f2-60e1-4d67-9971-c4bfe53770ef	a4cc7c91-919a-4c91-b906-0f64b3fad1d0	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	READY_FOR_COLLECTION	DELIVERED	Device handed over in functional state with original charger and old SSD returned.	2026-10-28 15:31:39.529
35488497-28f6-4660-ab5f-a7b75c5223f4	ac48cc9d-4c11-4187-a9c9-d274be09aace	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	RECEIVED	RECEIVED	Initial hardware intake completed.	2026-10-28 15:38:38.795
71d81df6-eaff-4dc1-903b-9de1726aeeae	91939b80-1b64-4b28-98f1-2531cef8fb84	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	RECEIVED	RECEIVED	Initial hardware intake completed.	2026-10-28 15:42:06.701
a0198e79-02b6-4a3b-8d67-0b0fc32e0d30	247a7fb5-f504-4cdd-9639-d6664932ac78	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	RECEIVED	RECEIVED	Initial hardware intake completed.	2026-10-28 15:42:15.058
a7493f9b-3bd8-4fbd-9992-66002b60a38a	7be48258-b929-46f5-ac2e-c02a60b06b8a	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	RECEIVED	RECEIVED	Initial hardware intake completed.	2026-10-28 18:50:33.214
66968bf3-de4b-4d42-aa17-865059b04cee	7be48258-b929-46f5-ac2e-c02a60b06b8a	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	RECEIVED	UNDER_DIAGNOSIS	Diagnosis recorded: Estimate NPR 7500	2026-10-28 18:50:33.271
cf83bd5e-f200-4630-83ee-9a26f993d1be	7be48258-b929-46f5-ac2e-c02a60b06b8a	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	UNDER_DIAGNOSIS	IN_REPAIR	Customer approved estimate.	2026-10-28 18:50:33.3
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StockMovement" (id, "productId", "userId", "movementType", "quantityDelta", "unitCost", "referenceId", notes, "createdAt") FROM stdin;
628acb8c-ba33-44c4-94a1-ec6676ac5a71	84c03562-ec15-47c0-b86a-01962f2f1a55	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	STOCK_ADJUSTMENT	5	4200.00	\N	Initial workshop spare parts stock intake	2026-10-28 15:25:15.908
e6e9d3e9-ebd4-4b24-a07f-4488ec29fcf0	bbc7363d-5a50-445c-8028-526be96cdd25	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	STOCK_ADJUSTMENT	5	4200.00	\N	Initial workshop spare parts stock intake	2026-10-28 15:31:39.203
9c0f198c-2075-41b5-a799-fa9c4b8264fd	bbc7363d-5a50-445c-8028-526be96cdd25	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	REPAIR_CONSUMPTION	-1	4200.00	JOB-20261028-0001	Consumed for Repair Job JOB-20261028-0001	2026-10-28 15:31:39.438
81d66eaa-fa50-4b88-848b-a1f519694b73	e4ba8a79-76df-48a1-8085-3bb61be5126e	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	STOCK_ADJUSTMENT	2	6500.00	\N	POS inventory batch intake	2026-10-28 15:38:38.673
a9a719fe-44e6-4c57-805f-eedbb42530a3	b08173c3-024a-40f4-bc15-7dc70d449d4e	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	STOCK_ADJUSTMENT	2	6500.00	\N	POS inventory batch intake	2026-10-28 15:42:06.582
89d430fe-f5ff-4204-9fa1-dfb70d8230b4	b08173c3-024a-40f4-bc15-7dc70d449d4e	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	SALE_DEDUCTION	-1	6500.00	INV-20261028-0001	POS Sale: INV-20261028-0001	2026-10-28 15:42:07.038
7bd878c9-782f-4588-99d3-bae1f1ebc0fd	b08173c3-024a-40f4-bc15-7dc70d449d4e	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	SALE_DEDUCTION	-1	6500.00	INV-20261028-0002	POS Sale: INV-20261028-0002	2026-10-28 15:42:07.237
97bbf999-d5f6-4c08-99e4-59aa2d1d2415	c1d1f985-b515-4960-b213-42185e0939af	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	STOCK_ADJUSTMENT	2	6500.00	\N	POS inventory batch intake	2026-10-28 15:42:14.942
cf316a07-baea-49be-80ce-128c02836fa7	c1d1f985-b515-4960-b213-42185e0939af	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	SALE_DEDUCTION	-1	6500.00	INV-20261028-0003	POS Sale: INV-20261028-0003	2026-10-28 15:42:15.422
52aa2869-fa29-4204-b32e-6f0bafa97fdc	c1d1f985-b515-4960-b213-42185e0939af	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	SALE_DEDUCTION	-1	6500.00	INV-20261028-0004	POS Sale: INV-20261028-0004	2026-10-28 15:42:15.576
715d1726-8056-47a8-991f-05784522a2c3	84c03562-ec15-47c0-b86a-01962f2f1a55	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	SALE_DEDUCTION	-1	4200.00	INV-20261028-0005	POS Sale: INV-20261028-0005	2026-10-28 18:41:09.879
6143057d-27e0-4501-a9e1-88bf4e0867fb	84c03562-ec15-47c0-b86a-01962f2f1a55	9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	REPAIR_CONSUMPTION	-1	4200.00	JOB-20261028-0005	Consumed for Repair Job JOB-20261028-0005	2026-10-28 18:50:33.33
\.


--
-- Data for Name: Supplier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Supplier" (id, "companyName", "contactPerson", email, phone, address, "taxNumber", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, username, email, "passwordHash", "fullName", role, "isActive", "createdAt", "updatedAt") FROM stdin;
9ce1c440-e311-4f7a-a48c-ef69a5b9b50c	admin	admin@nexusedge.internal	$argon2id$v=19$m=65536,t=3,p=4$9R7DiVsJknbmW+u7G82eZg$sHt71zz9hkWy9W9d/iBFN1fGEd/xwUB4l/E8FE5keA0	System Administrator	OWNER	t	2026-10-28 15:14:25.93	2026-10-28 15:14:25.93
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
6a10b5d8-00cd-422e-9e82-23c185abe169	c85be3a95f1e978e49c492f8d40493895eeaa247fff6a9011c6ca6bd84dbdc84	2026-10-28 15:14:23.973769+00	20261028151422_init	\N	\N	2026-10-28 15:14:22.473682+00	1
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: InvoiceItem InvoiceItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: JournalEntry JournalEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_pkey" PRIMARY KEY (id);


--
-- Name: JournalLine JournalLine_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalLine"
    ADD CONSTRAINT "JournalLine_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: ProductSerial ProductSerial_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductSerial"
    ADD CONSTRAINT "ProductSerial_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: PurchaseOrderItem PurchaseOrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrderItem"
    ADD CONSTRAINT "PurchaseOrderItem_pkey" PRIMARY KEY (id);


--
-- Name: PurchaseOrder PurchaseOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrder"
    ADD CONSTRAINT "PurchaseOrder_pkey" PRIMARY KEY (id);


--
-- Name: RepairJob RepairJob_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairJob"
    ADD CONSTRAINT "RepairJob_pkey" PRIMARY KEY (id);


--
-- Name: RepairPartUsage RepairPartUsage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairPartUsage"
    ADD CONSTRAINT "RepairPartUsage_pkey" PRIMARY KEY (id);


--
-- Name: RepairStatusHistory RepairStatusHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairStatusHistory"
    ADD CONSTRAINT "RepairStatusHistory_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Supplier Supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Supplier"
    ADD CONSTRAINT "Supplier_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Account_accountCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Account_accountCode_key" ON public."Account" USING btree ("accountCode");


--
-- Name: Customer_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Customer_phone_idx" ON public."Customer" USING btree (phone);


--
-- Name: Customer_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_phone_key" ON public."Customer" USING btree (phone);


--
-- Name: InvoiceItem_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "InvoiceItem_invoiceId_idx" ON public."InvoiceItem" USING btree ("invoiceId");


--
-- Name: InvoiceItem_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "InvoiceItem_productId_idx" ON public."InvoiceItem" USING btree ("productId");


--
-- Name: Invoice_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_createdAt_idx" ON public."Invoice" USING btree ("createdAt");


--
-- Name: Invoice_invoiceNo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_invoiceNo_idx" ON public."Invoice" USING btree ("invoiceNo");


--
-- Name: Invoice_invoiceNo_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Invoice_invoiceNo_key" ON public."Invoice" USING btree ("invoiceNo");


--
-- Name: JournalEntry_entryNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "JournalEntry_entryNumber_key" ON public."JournalEntry" USING btree ("entryNumber");


--
-- Name: Payment_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_invoiceId_idx" ON public."Payment" USING btree ("invoiceId");


--
-- Name: Payment_method_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_method_idx" ON public."Payment" USING btree (method);


--
-- Name: ProductSerial_macAddress_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductSerial_macAddress_idx" ON public."ProductSerial" USING btree ("macAddress");


--
-- Name: ProductSerial_productId_serialNo_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ProductSerial_productId_serialNo_key" ON public."ProductSerial" USING btree ("productId", "serialNo");


--
-- Name: ProductSerial_serialNo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductSerial_serialNo_idx" ON public."ProductSerial" USING btree ("serialNo");


--
-- Name: Product_barcode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_barcode_idx" ON public."Product" USING btree (barcode);


--
-- Name: Product_barcode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_barcode_key" ON public."Product" USING btree (barcode);


--
-- Name: Product_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_category_idx" ON public."Product" USING btree (category);


--
-- Name: Product_sku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_sku_idx" ON public."Product" USING btree (sku);


--
-- Name: Product_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_sku_key" ON public."Product" USING btree (sku);


--
-- Name: PurchaseOrder_orderNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PurchaseOrder_orderNumber_key" ON public."PurchaseOrder" USING btree ("orderNumber");


--
-- Name: RepairJob_jobNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RepairJob_jobNumber_idx" ON public."RepairJob" USING btree ("jobNumber");


--
-- Name: RepairJob_jobNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RepairJob_jobNumber_key" ON public."RepairJob" USING btree ("jobNumber");


--
-- Name: RepairJob_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RepairJob_status_idx" ON public."RepairJob" USING btree (status);


--
-- Name: RepairPartUsage_repairJobId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RepairPartUsage_repairJobId_idx" ON public."RepairPartUsage" USING btree ("repairJobId");


--
-- Name: RepairStatusHistory_repairJobId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RepairStatusHistory_repairJobId_idx" ON public."RepairStatusHistory" USING btree ("repairJobId");


--
-- Name: StockMovement_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StockMovement_productId_idx" ON public."StockMovement" USING btree ("productId");


--
-- Name: StockMovement_referenceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StockMovement_referenceId_idx" ON public."StockMovement" USING btree ("referenceId");


--
-- Name: Supplier_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Supplier_phone_key" ON public."Supplier" USING btree (phone);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: InvoiceItem InvoiceItem_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InvoiceItem InvoiceItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JournalEntry JournalEntry_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JournalLine JournalLine_creditAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalLine"
    ADD CONSTRAINT "JournalLine_creditAccountId_fkey" FOREIGN KEY ("creditAccountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JournalLine JournalLine_debitAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalLine"
    ADD CONSTRAINT "JournalLine_debitAccountId_fkey" FOREIGN KEY ("debitAccountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JournalLine JournalLine_journalEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalLine"
    ADD CONSTRAINT "JournalLine_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES public."JournalEntry"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductSerial ProductSerial_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductSerial"
    ADD CONSTRAINT "ProductSerial_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductSerial ProductSerial_stockMovementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductSerial"
    ADD CONSTRAINT "ProductSerial_stockMovementId_fkey" FOREIGN KEY ("stockMovementId") REFERENCES public."StockMovement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PurchaseOrderItem PurchaseOrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrderItem"
    ADD CONSTRAINT "PurchaseOrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PurchaseOrderItem PurchaseOrderItem_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrderItem"
    ADD CONSTRAINT "PurchaseOrderItem_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public."PurchaseOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PurchaseOrder PurchaseOrder_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrder"
    ADD CONSTRAINT "PurchaseOrder_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public."Supplier"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RepairJob RepairJob_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairJob"
    ADD CONSTRAINT "RepairJob_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RepairJob RepairJob_technicianId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairJob"
    ADD CONSTRAINT "RepairJob_technicianId_fkey" FOREIGN KEY ("technicianId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RepairPartUsage RepairPartUsage_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairPartUsage"
    ADD CONSTRAINT "RepairPartUsage_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RepairPartUsage RepairPartUsage_repairJobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairPartUsage"
    ADD CONSTRAINT "RepairPartUsage_repairJobId_fkey" FOREIGN KEY ("repairJobId") REFERENCES public."RepairJob"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RepairStatusHistory RepairStatusHistory_repairJobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairStatusHistory"
    ADD CONSTRAINT "RepairStatusHistory_repairJobId_fkey" FOREIGN KEY ("repairJobId") REFERENCES public."RepairJob"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RepairStatusHistory RepairStatusHistory_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RepairStatusHistory"
    ADD CONSTRAINT "RepairStatusHistory_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockMovement StockMovement_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict jsv1hY5Lbi0TGNTjBfokd9uu8bHx2cD8eA8AYgSVeKezG63COO8FKh6mu1pxyId

